<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Category</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <%@ include file="homeHeader.jsp" %>

    <div class="form-container">
        <h2>Add New Category</h2>
		<p style="color:green; text-align:center;">${msg}</p>
        <form action="add-category" method="post" class="category-form">
            <label for="name">Category Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter category name" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" placeholder="Enter category description"></textarea>

            <button type="submit" class="btn-submit">Add Category</button>
        </form>
    </div>

    <%@ include file="footer.jsp" %>
</body>
</html>
