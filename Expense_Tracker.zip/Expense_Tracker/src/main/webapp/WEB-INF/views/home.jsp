<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Expense Tracker</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<%@ include file="homeHeader.jsp" %>

<main class="dashboard">
    <h1>Welcome to Your Dashboard</h1>
    <p>Select an option below to manage your finances:</p>

    <!-- Income Section -->
    <section class="dashboard-section">
        <h2>💰 Income Management</h2>
        <div class="card-container">
            <div class="card">
                <h3>Add Income</h3>
                <p>Record your earnings and keep track of all income sources.</p>
                <a href="/get-add-income-page" class="btn">Add</a>
            </div>
            <div class="card">
                <h3>Delete Income</h3>
                <p>Remove an existing income entry from your records.</p>
                <a href="/get-delete-income-page" class="btn">Delete</a>
            </div>
            <div class="card">
                <h3>View All Income</h3>
                <p>See a list of all your income entries.</p>
                <a href="/view-income" class="btn">View</a>
            </div>
        </div>
    </section>

    <!-- Expense Section -->
    <section class="dashboard-section">
        <h2>💸 Expense Management</h2>
        <div class="card-container">
            <div class="card">
                <h3>Add Expense</h3>
                <p>Track where your money goes by adding new expenses.</p>
                <a href="/get-add-expense-page" class="btn">Add</a>
            </div>
            <div class="card">
                <h3>Delete Expense</h3>
                <p>Remove an existing expense entry from your records.</p>
                <a href="/get-delete-expense-page" class="btn">Delete</a>
            </div>
            <div class="card">
                <h3>View All Expenses</h3>
                <p>Get a detailed view of all your spending.</p>
                <a href="/view-expenses" class="btn">View</a>
            </div>
        </div>
    </section>

    <!-- Category Section -->
    <section class="dashboard-section">
        <h2>📂 Category Management</h2>
        <div class="card-container">
            <div class="card">
                <h3>Add Category</h3>
                <p>Create a new category for better expense organization.</p>
                <a href="/get-add-category-page" class="btn">Add</a>
            </div>
            <div class="card">
                <h3>Delete Category</h3>
                <p>Remove an existing category from your list.</p>
                <a href="/get-delete-category-page" class="btn">Delete</a>
            </div>
            <div class="card">
                <h3>View All Categories</h3>
                <p>See all the categories you have created.</p>
                <a href="/view-category" class="btn">View</a>
            </div>
        </div>
    </section>
</main>

<%@ include file="footer.jsp" %>

</body>
</html>
