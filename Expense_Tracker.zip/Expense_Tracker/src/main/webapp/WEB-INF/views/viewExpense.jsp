<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Expenses</title>
    <link rel="stylesheet" href="../css/style.css">
    <script>
        // Simple JS function to print table
        function printExpenses() {
            const printContents = document.getElementById('expensesTable').outerHTML;
            const originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload(); // reload to restore JS events
        }
    </script>
</head>
<body>
    <%@ include file="homeHeader.jsp" %>

    <div class="view-container">
        <h2 class="view-title">📊 Your Expenses</h2>

        <!-- Filter -->
        <form action="/view-expenses" method="get" class="filter-form">
            <label for="categoryFilter">Filter by Category:</label>
            <select name="categoryId" id="categoryFilter" onchange="this.form.submit()">
                <option value="0">All</option>
                <c:forEach var="cat" items="${categories}">
                    <option value="${cat.categoryId}" <c:if test="${selectedCategoryId == cat.categoryId}">selected</c:if>>
                        ${cat.name}
                    </option>
                </c:forEach>
            </select>
        </form>

        <!-- Expense Table -->
        <table id="expensesTable" class="styled-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Category</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="exp" items="${expenses}">
                    <tr>
                        <td>${exp.title}</td>
                        <td>${exp.amount}</td>
                        <td>${exp.date}</td>
                        <td>${exp.category.name}</td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>

        <!-- Print Button -->
        <div class="print-btn-container">
            <button onclick="printExpenses()" class="btn-print">🖨 Print</button>
        </div>
    </div>

</body>
</html>
