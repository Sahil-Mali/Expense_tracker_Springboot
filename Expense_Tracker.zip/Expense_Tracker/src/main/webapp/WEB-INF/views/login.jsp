<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="header.jsp" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login - Expense Tracker</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<main class="auth-container">
    <div class="auth-box">
        <h2>Login</h2>
		<p style="color:green; text-align:center;">${msg}</p>

        <form action="/verifyLogin" method="post">
            <div class="form-group">
				<label>User Name</label>
				<input type="text" name="name" required placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Enter your password">
            </div>
            <button type="submit" class="auth-btn">Login</button>
        </form>
        <p class="auth-switch">Don't have an account? 
            <a href="/get-signup-page">Sign Up</a>
        </p>
    </div>
</main>

<%@ include file="footer.jsp" %>
</body>
</html>
