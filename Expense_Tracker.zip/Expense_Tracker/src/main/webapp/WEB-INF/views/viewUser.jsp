<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View User</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <%@ include file="headerUser.jsp" %>

    <div class="view-container">
        <h2 class="view-title">👤 User Information</h2>

        <table class="styled-table">
            <tbody>
                <tr>
                    <th>User ID</th>
                    <td>${user.userId}</td>
                </tr>
                <tr>
                    <th>Full Name</th>
                    <td>${user.fullName}</td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>${user.email}</td>
                </tr>
                
            </tbody>
        </table>
    </div>
</body>
</html>
