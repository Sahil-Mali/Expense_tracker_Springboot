<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Delete Expense</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <%@ include file="homeHeader.jsp" %>

    <div class="form-container">
        <h2 class="form-title">🗑 Delete Expense</h2>
		<p style="color:green; text-align:center;">${msg}</p>

        <form action="/delete-expense" method="post" class="styled-form">
            <label for="expenseId">Select Expense to Delete:</label>
            <select id="expenseId" name="expenseId" required>
                <option value="">-- Select Expense --</option>
                <c:forEach var="exp" items="${expenses}">
                    <option value="${exp.expenseId}">
                        ${exp.title} - ${exp.amount} on ${exp.date} (${exp.category.name})
                    </option>
                </c:forEach>
            </select>

            <button type="submit" class="btn btn-danger">Delete Expense</button>
        </form>
    </div>

</body>
</html>
