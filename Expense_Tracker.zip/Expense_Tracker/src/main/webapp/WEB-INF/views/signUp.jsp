<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="header.jsp" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login - Expense Tracker</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<main class="auth-container">
    <div class="auth-box">
        <h2>Create Account</h2>
        <form action="/add-user" method="post">
            <div class="form-group">
                <label>User Name</label>
                <input type="text" name="name" required placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Enter your password">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirmPassword" required placeholder="Confirm your password">
            </div>
            <button type="submit" class="auth-btn">Sign Up</button>
        </form>
        <p class="auth-switch">Already have an account? 
            <a href="/get-login-page">Login</a>
        </p>
    </div>
</main>

<%@ include file="footer.jsp" %>
</body>
</html>
