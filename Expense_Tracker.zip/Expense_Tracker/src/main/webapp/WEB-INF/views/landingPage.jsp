<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<%@ include file="header.jsp" %>

<main class="landing-container">
    <!-- Hero Section -->
    <section class="hero">
        <h1>Take Control of Your Expenses</h1>
        <p>Track, manage, and analyze your spending with ease. Our smart Expense Tracker helps you save more and spend wisely.</p>
        <a href="/get-signup-page" class="cta-btn">Get Started Free</a>
    </section>

    <!-- Features Section -->
    <section class="features">
        <h2>Why Choose Expense Tracker?</h2>
        <div class="feature-grid">
            <div class="feature">
                <h3>💡 Simple & Intuitive</h3>
                <p>Easily log your daily expenses with just a few clicks.</p>
            </div>
            <div class="feature">
                <h3>📊 Smart Reports</h3>
                <p>Get insights on your spending habits with monthly and category-wise reports.</p>
            </div>
            <div class="feature">
                <h3>🔒 Secure</h3>
                <p>Your data is protected with secure authentication and encryption.</p>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials">
        <h2>What Our Users Say</h2>
        <div class="testimonial">
            <p>"This app changed the way I manage my money. Highly recommend!"</p>
            <span>- Rahul, Student</span>
        </div>
        <div class="testimonial">
            <p>"Finally a simple tool that keeps my expenses organized and easy to track."</p>
            <span>- Ananya, Working Professional</span>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="cta-section">
        <h2>Start Tracking Your Expenses Today!</h2>
        <a href="/get-signup-page" class="cta-btn">Create Free Account</a>
    </section>
</main>

<%@ include file="footer.jsp" %>
</html>

