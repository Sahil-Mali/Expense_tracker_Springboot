<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Delete Category</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <%@ include file="homeHeader.jsp" %>

    <div class="form-container">
        <h2>Delete Category</h2>
		<p style="color:green; text-align:center;">${msg}</p>
        <form action="/delete-category" method="post" class="styled-form">
            <label for="categoryId">Select Category to Delete:</label>
            <select name="categoryId" id="categoryId" required>
                <option value="">-- Select Category --</option>
                <c:forEach var="cat" items="${categoryList}">
                    <option value="${cat.categoryId}">${cat.name}</option>
                </c:forEach>
            </select>

            <button type="submit" class="btn btn-danger">Delete Category</button>
        </form>
    </div>
</body>
</html>
