<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Categories</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <%@ include file="homeHeader.jsp" %>

    <main class="container">
        <h2 class="page-title">📂 View All Categories</h2>

        <c:if test="${empty categories}">
            <p class="no-data">No categories found. Please add one.</p>
        </c:if>

        <c:if test="${not empty categories}">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Category ID</th>
                        <th>Category Name</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
					<c:forEach var="cat" items="${categories}">
					    <tr>
					        <td>${cat.categoryId}</td>
					        <td>${cat.name}</td>
					        <td>${cat.description}</td>
					    </tr>
					</c:forEach>
                </tbody>
            </table>
        </c:if>
    </main>

    <%@ include file="footer.jsp" %>
</body>
</html>
