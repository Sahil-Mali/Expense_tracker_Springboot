<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Delete Income</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <%@ include file="homeHeader.jsp" %>

    <div class="form-container">
        <h2>Delete Income</h2>
		<p style="color:green; text-align:center;">${msg}</p>
        <form action="/delete-income" method="post" class="delete-form">
            <label for="incomeId">Income ID:</label>
            <input type="number" id="incomeId" name="incomeId" required>

            <button type="submit" class="delete-btn">Delete</button>
        </form>
    </div>

    <%@ include file="footer.jsp" %>
</body>
</html>
