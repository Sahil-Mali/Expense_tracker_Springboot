<header class="site-header">
    <div class="logo">
        <img src="/images/logo.jpg" alt="Expense Tracker Logo">
        <span class="site-name">Expense Tracker</span>
    </div>
    <nav class="nav-links">
        <a href="/get-home-page">Home</a>
        <a href="#">View User</a>
        <a href="/" class="logout-btn">Logout</a>
    </nav>
</header>
