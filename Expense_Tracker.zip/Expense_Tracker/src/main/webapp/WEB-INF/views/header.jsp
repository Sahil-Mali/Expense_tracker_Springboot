<header class="site-header">
    <div class="logo">
        <img src="/images/logo.jpg" alt="Expense Tracker Logo">
        <span class="site-name">Expense Tracker</span>
    </div>
    <nav class="nav-links">
        <a href="/get-login-page">Login</a>
        <a href="/get-signup-page" class="signup-btn">Sign Up</a>
    </nav>
</header>
