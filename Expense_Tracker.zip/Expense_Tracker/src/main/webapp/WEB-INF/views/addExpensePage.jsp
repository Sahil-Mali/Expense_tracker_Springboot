<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Expense</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <%@ include file="homeHeader.jsp" %>

    <main class="form-container">
        <h2 class="form-title">💸 Add New Expense</h2>
		<p style="color:green; text-align:center;">${msg}</p>

        <form action="/add-expense" method="post" class="styled-form">
            <!-- Title -->
            <div class="form-group">
                <label for="title">Expense Title</label>
                <input type="text" id="title" name="title" placeholder="e.g. Grocery Shopping" required>
            </div>

            <!-- Amount -->
            <div class="form-group">
                <label for="amount">Amount</label>
                <input type="number" id="amount" name="amount" placeholder="Enter expense amount" required>
            </div>

            <!-- Date -->
            <div class="form-group">
                <label for="date">Date</label>
                <input type="date" id="date" name="date" required>
            </div>

            <!-- Category -->
            <div class="form-group">
				<label for="category">Category</label>
				<select id="category" name="category.categoryId" required>
				    <option value="">-- Select Category --</option>
				    <c:forEach var="cat" items="${categories}">
				        <option value="${cat.categoryId}">${cat.name}</option>
				    </c:forEach>
				</select>
            </div>

            <!-- Submit -->
            <div class="form-actions">
                <button type="submit" class="btn-submit">Add Expense</button>
                <button type="reset" class="btn-reset">Clear</button>
            </div>
        </form>
    </main>

    <%@ include file="footer.jsp" %>
</body>
</html>
