<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Income - Expense Tracker</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<%@ include file="homeHeader.jsp" %>

<main class="form-container">
    <h1>Add Income</h1>
	<p style="color:green; text-align:center;">${msg}</p>

    <form action="/add-income" method="post" class="income-form">
        
        <div class="form-group">
            <label for="source">Income Source</label>
            <input type="text" id="source" name="source" placeholder="e.g. Salary, Freelance, Investment" required>
        </div>

        <div class="form-group">
            <label for="amount">Amount (₹)</label>
            <input type="number" id="amount" name="amount" step="0.01" placeholder="Enter amount" required>
        </div>

        <div class="form-group">
            <label for="date">Date</label>
            <input type="date" id="date" name="date" required>
        </div>

        <button type="submit" class="btn">Save Income</button>
    </form>
</main>

<%@ include file="footer.jsp" %>

</body>
</html>
