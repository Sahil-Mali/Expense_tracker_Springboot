package com.tka.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tka.model.Expenses;

@Repository
public interface ExpenseDao extends JpaRepository<Expenses, Integer>{

	List<Expenses> findByCategoryCategoryId(int categoryId);

}
