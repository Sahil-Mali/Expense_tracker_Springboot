package com.tka.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tka.model.Income;

@Repository
public interface IncomeDao extends JpaRepository<Income, Integer> {

}
