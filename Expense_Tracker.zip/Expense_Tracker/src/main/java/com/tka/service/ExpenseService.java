package com.tka.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.ExpenseDao;
import com.tka.model.Expenses;

@Service
public class ExpenseService {
	@Autowired
	ExpenseDao expenseDao;

	public boolean addExpense(Expenses expense) {
		Expenses expenseAdded = expenseDao.save(expense);
		if (expenseAdded != null) {
			return true;
		}
		return false;
	}
	
	public List<Expenses> getAllExpenses(){
		List<Expenses> expenseList = expenseDao.findAll();
		return expenseList;
	}

	public boolean deleteExpense(int expenseId) {
		if (expenseDao.existsById(expenseId)) {
			expenseDao.deleteById(expenseId);
			return true;
		}
		return false;
	}
	

    public List<Expenses> getExpensesByCategory(int categoryId) {
        return expenseDao.findByCategoryCategoryId(categoryId);
    }

}
