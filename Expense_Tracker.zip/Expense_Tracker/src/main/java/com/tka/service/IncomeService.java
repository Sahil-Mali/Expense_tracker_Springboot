package com.tka.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.IncomeDao;
import com.tka.model.Income;

@Service
public class IncomeService {
	@Autowired
	IncomeDao incomeDao;

	public boolean addIncome(Income income) {
		Income incomeAdded = incomeDao.save(income);
		if(incomeAdded != null) {
			return true;
		}
		return false;
	}
	
	public boolean deleteIncome(int id) {
        Optional<Income> deleteIncome = incomeDao.findById(id);
        if (deleteIncome.isPresent()) {
        	incomeDao.deleteById(id);
        	return true;
        } else {
            throw new RuntimeException("Income with ID " + id + " not found");
            
        }
    }

	public List<Income> viewIncome() {
		return incomeDao.findAll();
	}

}
