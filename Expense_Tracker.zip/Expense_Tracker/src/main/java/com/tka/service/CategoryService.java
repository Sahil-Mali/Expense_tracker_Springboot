package com.tka.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.CategoryDao;
import com.tka.model.Category;
import com.tka.model.Income;

@Service
public class CategoryService {
	@Autowired
	CategoryDao categoryDao;

	public boolean addCategory(Category category) {
		Category categoryAdded = categoryDao.save(category);
		if (categoryAdded != null) {
			return true;
		}
		return false;
	}

	public List<Category> getAllCategories() {
		return categoryDao.findAll();
	}

	public boolean deleteCategory(int categoryId) {
		Optional<Category> deleteIncome = categoryDao.findById(categoryId);
        if (deleteIncome.isPresent()) {
        	categoryDao.deleteById(categoryId);
        	return true;
        } else {
            throw new RuntimeException("Income with ID " + categoryId + " not found");
            
        }
	}



}
