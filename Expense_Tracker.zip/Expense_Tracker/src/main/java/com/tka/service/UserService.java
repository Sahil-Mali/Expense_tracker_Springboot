package com.tka.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.UserDao;
import com.tka.model.User;

@Service
public class UserService {

	@Autowired
	UserDao userDao;
	
	public boolean register(User user) {
		User saveUser = userDao.save(user);
		if(saveUser != null) {
			return true;
		}
		return false;
	}
	
	public boolean verifyLogin(String username, String password) {
		List<User> userList = userDao.findAll();
		for (User user : userList) {
			if (user.getName().equals(username)) {
				if (user.getPassword().equals(password)) {
					return true;
				}
			}
			
		}
		return false;
	}

	public User getUserById(int userId) {
		return userDao.findById(userId).orElse(null);
	}
}
