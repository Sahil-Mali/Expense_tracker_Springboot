package com.tka.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Component
@Entity
public class Income {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int incomeId;
	private String source;
	private double amount;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate date;
	
	@ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
	
	public Income() {
		// TODO Auto-generated constructor stub
	}

	public Income(int incomeId, String source, double amount, LocalDate date, User user) {
		super();
		this.incomeId = incomeId;
		this.source = source;
		this.amount = amount;
		this.date = date;
		this.user = user;
	}

	public int getIncomeId() {
		return incomeId;
	}

	public void setIncomeId(int incomeId) {
		this.incomeId = incomeId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Income [incomeId=" + incomeId + ", source=" + source + ", amount=" + amount + ", date=" + date
				+ ", user=" + user + "]";
	}
	
	
}
