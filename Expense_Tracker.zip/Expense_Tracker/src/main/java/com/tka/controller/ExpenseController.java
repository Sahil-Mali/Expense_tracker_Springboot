package com.tka.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tka.model.Category;
import com.tka.model.Expenses;
import com.tka.service.CategoryService;
import com.tka.service.ExpenseService;

@Controller
public class ExpenseController {
	@Autowired
	ExpenseService expenseService;
	@Autowired
	CategoryService categoryService;
	String msg;
	
	@GetMapping("/get-add-expense-page")
    public String getAddExpensePage(Model model) {
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);

        return "addExpensePage";
    }
	
	@PostMapping("/add-expense")
	public String addExpense(@ModelAttribute Expenses expense, Model model) {
		boolean isAdded = expenseService.addExpense(expense);
		if(isAdded) {
			msg = "Expense Added Successfully..";
		}
		else {
			msg = "Something went wrong..  'Try Again!'..";
		}
		model.addAttribute("msg", msg);
		return "addExpensePage";
		
	}
	
	@GetMapping("/get-delete-expense-page")
	public String getDeleteExpensePage(Model model) {
	    List<Expenses> expenses = expenseService.getAllExpenses();
	    model.addAttribute("expenses", expenses);
	    return "deleteExpensePage";
	}
	
	@PostMapping("/delete-expense")
	public String deleteExpense(@RequestParam("expenseId") int expenseId, Model model) {
		boolean isDeleted = expenseService.deleteExpense(expenseId);
		if(isDeleted) {
			msg = "Expense Deleted...";
		}
		else {
			msg = "Something went wrong..  'Try Again!'..";
		}
		model.addAttribute("msg", msg);
		return "deleteExpensePage";
	}
	
	 @GetMapping("/view-expenses")
	    public String viewExpenses(@RequestParam(value="categoryId", defaultValue="0") int categoryId, Model model) {
	        List<Expenses> expenses;

	        if (categoryId == 0) {
	            expenses = expenseService.getAllExpenses();
	        } else {
	            expenses = expenseService.getExpensesByCategory(categoryId);
	        }

	        List<Category> categories = categoryService.getAllCategories();

	        model.addAttribute("expenses", expenses);
	        model.addAttribute("categories", categories);
	        model.addAttribute("selectedCategoryId", categoryId);

	        return "viewExpense";
	    }

	
}
