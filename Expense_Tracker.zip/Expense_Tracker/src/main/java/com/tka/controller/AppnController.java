package com.tka.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AppnController {
	
	@GetMapping("/")
	public String getLandingPage() {
		return "landingPage";
	}
	
	@GetMapping("/get-login-page")
	public String getLoginPage() {
		return "login";
	}
	
	@GetMapping("/get-signup-page")
	public String getSignUpPage() {
		return "signUp";
	}
	
	@GetMapping("/get-home-page")
	public String getHomePage() {
		return "home";
	}

}
