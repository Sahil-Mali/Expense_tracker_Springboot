package com.tka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tka.model.User;
import com.tka.service.UserService;

@Controller
public class UserController {
	@Autowired
	UserService userService;
	String msg;
	
	@PostMapping("/add-user")
	public String register(@ModelAttribute User user, Model model) {
		boolean isAdded = userService.register(user);
		if(isAdded) {
			msg = "User Sign up successful..";
		}
		else {
			msg = "User Sign up Unsuccessful..";
		}
		model.addAttribute("msg", msg);
		return "login";
	}
	
	@PostMapping("/verifyLogin")
	public String verifyLogin(@RequestParam String name, @RequestParam String password, Model model) {
		boolean isVerify = userService.verifyLogin(name, password);
		if(isVerify) {
			msg = name + " >> Login Successfull..";
			model.addAttribute("msg", msg);
			return "home";
		}
		msg = "Login Unsuccessfull..";
		model.addAttribute("msg", msg);
		return "login";
	}
	
	@GetMapping("/view-user")
	public String viewUser(@RequestParam("userId") int userId, Model model) {
	    User user = userService.getUserById(userId);
	    model.addAttribute("user", user);
	    return "viewUser";
	}


}
