package com.tka.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tka.model.Income;
import com.tka.service.IncomeService;

@Controller
public class IncomeController {
	@Autowired
	IncomeService incomeService;
	String msg;
	
	@GetMapping("/get-add-income-page")
	public String getAddIncomePage() {
		return "addIncomePage";
	}
	
	@PostMapping("/add-income")
	public String addIncome(@ModelAttribute Income income, Model model) {
		boolean isAdded = incomeService.addIncome(income);
		if(isAdded) {
			msg = "Income Added Successfully..";
		}
		else {
			msg = "Something went wrong..  'Try Again!'..";
		}
		model.addAttribute("msg", msg);
		return "addIncomePage";
		
	}
	
	@GetMapping("/get-delete-income-page")
	public String getDeleteIncomePage() {
		return "deleteIncomePage";
	}
	
	 @PostMapping("/delete-income")
	 public String deleteIncome(@RequestParam("incomeId") int id, Model model) {
		 boolean isDeleted = incomeService.deleteIncome(id);
		 if (isDeleted) {
			 msg= "Income Deleted Successfully..";
		 }
		 else {
			 msg = "Something went wrong..  'Try Again'..";
		 }
		 model.addAttribute("msg", msg);
	     return "deleteIncomePage"; 
	 }
	 
	 @GetMapping("/view-income")
	 public String viewIncome(Model model) {
		 List<Income> incomeList = incomeService.viewIncome();
		 model.addAttribute("incomeList", incomeList);
		 return "viewIncome";
	 }

}
