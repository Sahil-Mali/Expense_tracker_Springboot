package com.tka.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tka.model.Category;
import com.tka.model.Income;
import com.tka.service.CategoryService;

@Controller
public class CategoryController {
	@Autowired
	CategoryService categoryService;
	String msg;
	
	@GetMapping("/get-add-category-page")
	public String getAddCategoryPage() {
		return "addCategoryPage";
	}
	
	@PostMapping("/add-category")
	public String addCategory(@ModelAttribute Category category, Model model) {
		boolean isAdded = categoryService.addCategory(category);
		if(isAdded) {
			msg = "Category Added Successfully..";
		}
		else {
			msg = "Something went wrong..  'Try Again!'..";
		}
		model.addAttribute("msg", msg);
		return "addCategoryPage";
		
	}
	
	@GetMapping("/get-delete-category-page")
    public String getDeleteCategoryPage(Model model) {
        List<Category> categoryList = categoryService.getAllCategories();
        model.addAttribute("categoryList", categoryList);
        return "deleteCategory";
    }

    @PostMapping("/delete-category")
    public String deleteCategory(@RequestParam("categoryId") int categoryId, Model model) {
        boolean isDeleted = categoryService.deleteCategory(categoryId);
        if(isDeleted) {
        	msg = "Category Deleted...";
        }
        else {
        	msg = "Something went wrong..  'Try Again'..";
        }
        model.addAttribute("msg", msg);
        return "deleteCategory"; 
    }
    
    @GetMapping("/view-category")
	 public String viewCategory(Model model) {
		 List<Category> categories = categoryService.getAllCategories();
		 for (Category category : categories) {
			System.out.println(category);
		}
		 model.addAttribute("categories", categories);
		 return "viewCategory";
	 }

}
